<p align="center">
  <a href="https://xiaohuang257.github.io/RapeSenpai/index.html"><img src="https://github.com/Xiaohuang257/RapeSenpai/blob/main/static/image/ClickBefore.png?raw=true" width="100" height="100" alt="RapeSenpai"></a>
</p>
<div align="center">

# RapeSenpai
**新概念Home游戏**
</div>

## 简介
小游戏：雷普先辈

纯恶搞无恶意。
